# SimpleWesbite

A simple website built using angular showing the utilization of its components and data binding features for extensible management of web applications
